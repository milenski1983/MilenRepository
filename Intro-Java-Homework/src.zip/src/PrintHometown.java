
public class PrintHometown {
	public static void main(String[] args) {		
		String myHometown = "Kostinbrod";
		System.out.printf("My hometown is %1$s", myHometown);
	}
}